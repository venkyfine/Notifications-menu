//
//  NotificationViewController.swift
//  SIdeMenuScreen

import UIKit

class NotificationViewController: UIViewController {

    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var contentView: UIView!
    
    var closePressed: (() -> ())?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblView.register(NotificationTableViewCell.self)
        tblView.registerHeaderFooter(NotificationSectionHeaderView.self)
        // Do any additional setup after loading the view.
        dropShadow()
    }
    
    func dropShadow() {
        contentView.layer.masksToBounds = false
        contentView.layer.shadowOffset = CGSize(width: 2, height: 0)
        contentView.layer.shadowColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1).cgColor
        contentView.layer.shadowOpacity = 0.29
        contentView.layer.shadowPath = nil
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch: UITouch? = touches.first
        if touch?.view != contentView {
            closePressed?()
        }
    }
    
    @IBAction func closePressed(_ sender: UIButton) {
        closePressed?()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension NotificationViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: NotificationTableViewCell = tableView.cellForItemAtIndexPath(indexPath: indexPath)
        return cell
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let view = tableView.dequeueReusableHeaderFooterView(withIdentifier: NotificationSectionHeaderView.reuseIdentifier) as! NotificationSectionHeaderView
        if section == 0 {
            view.viewSeperator.isHidden = true
        }
        else {
            view.viewSeperator.isHidden = false
        }
        return view
    }
}
